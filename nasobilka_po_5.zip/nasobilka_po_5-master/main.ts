let n = 5
while (n <= 50) {
    basic.showNumber(n)
    n += 5
    basic.pause(1000)
}
basic.forever(function on_forever() {
    
})
