// Tady jsou testy. Při použití tohoto balíčku jako rozšíření nebude zkompilováno.
